//
//  AnotacaoViewController.swift
//  Notas Diarias
//
//  Created by WILLIAN SOUZA LIMA on 25/09/2019.
//  Copyright © 2019 Willian Souza Lima. All rights reserved.
//

import UIKit
import CoreData

class AnotacaoViewController: UIViewController {

    @IBOutlet weak var texto: UITextView!
    var context: NSManagedObjectContext!
    var anotacao: NSManagedObject!
    
    
    // Do any additional setup after loading the view.
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //configuracoes iniciais
        self.texto.becomeFirstResponder() //esse texto será o primeiro a usar o teclado
        if anotacao != nil { //atualizar
            if let textoRecuperado = anotacao.value(forKey: "texto"){
                self.texto.text = String(describing: textoRecuperado)
            }
            
        }else{
            self.texto.text = ""
            
        }
        
        
        //deixa a caixa de texto vazia
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        context = appDelegate.persistentContainer.viewContext
        //context é o nosso gerenciador, responsavel pela persistencia dos dados

    }
    
    @IBAction func salvar(_ sender: Any) {
        if anotacao != nil { //atualizar
            self.atualizarAnotacao()
        }else{
            self.salvarAnotacao() //cria um novo ou atualiza um item existente
        }
        
        
        //retorna para a tela inicial
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    //cria o metodo atualizar Anotação
    func atualizarAnotacao() {
        anotacao.setValue( self.texto.text, forKey: "texto")
        anotacao.setValue( Date(), forKey: "data")
        
        do {
            try context.save()
            print("Sucesso ao atualizar anotação")
        } catch let erro as Error {
            print("Erro ao atualizar anotação: \(erro.localizedDescription) ")
        }
        
    }
    
    //cria o metodo salvar Anotação
    func salvarAnotacao() {
        
        //Cria objeto para anotação
        let novaAnotacao = NSEntityDescription.insertNewObject(forEntityName: "Anotacao", into: context)
        
        //configura anotação
        novaAnotacao.setValue( self.texto.text , forKey: "texto")
        novaAnotacao.setValue( Date() , forKey: "data")
        
        do {
            try context.save()
            print("Sucesso ao salvar anotação")
        } catch let erro as Error {
            print("Erro ao salvar anotação: \(erro.localizedDescription) ")
        }
        
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
